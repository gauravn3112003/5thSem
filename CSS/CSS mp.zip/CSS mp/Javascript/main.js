const toggleMenuOpen = () => document.body.classList.toggle("open");

var images = [
  "https://scontent-bom1-1.xx.fbcdn.net/v/t39.30808-6/308827383_456220363207718_4476150833069546401_n.jpg?_nc_cat=105&ccb=1-7&_nc_sid=e3f864&_nc_ohc=Iuhwi7BMobsAX9P4PaI&_nc_ht=scontent-bom1-1.xx&oh=00_AfDW7NFW7mIQ4c_MofEze83oppBokiLjvdPLkHeosndGFw&oe=63949497",
  "https://scontent-bom1-2.xx.fbcdn.net/v/t39.30808-6/278965503_357965676374519_8459052742571158741_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=e3f864&_nc_ohc=ri1f8Xu57bIAX_K0lso&_nc_ht=scontent-bom1-2.xx&oh=00_AfCx7jxVNkWm9HIezRrIZL8o7hICQTjy6z_2KPx70E6ePQ&oe=6395AAF2",
  "https://cache.careers360.mobi/media/presets/200X133/colleges/social-media/media-gallery/17670/2021/1/11/Campus%20view%20of%20Government%20Polytechnic%20Arvi_Campus-view.jpg",
  "https://cdn.pixabay.com/photo/2022/11/25/10/29/cosmos-7615933__340.jpg",
];
var count = 0;
function previousImage() {
  if (count != 0) count--;
  var id = document.getElementById("imageId");
  id.src = images[count];
}
function nextImage() {
  if (count != 4) count++;
  var id = document.getElementById("imageId");
  id.src = images[count];
}
